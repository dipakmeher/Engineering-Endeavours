#include <sys/socket.h>

#include <sys/types.h>

#include <netinet/in.h>

#include <netdb.h>

#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <unistd.h>

#include <errno.h>

 
int sock;
void execute(char cmd[100]){

	char fname[100] ,ch, file2[65536];
	FILE *fp;
	int i=0;

	

//	strcat(cmd,next);

//	strcpy(exe,cmd);
	printf("Executing Command .......... %s",cmd);

	system(cmd);
//	system(exe);

	strcpy(fname,"file.txt");
	fp = fopen(fname,"r");	

	 while((ch = fgetc(fp)) != EOF){
      		file2[i]= ch;
		i++;
	 }
	

	 send(sock,file2,strlen(file2), 0);
}

int main()

{

        char sendMessage[512],receiveMessage[512];

        int result; 

        struct hostent *host;

        struct sockaddr_in serverAdd; 

        host = gethostbyname("127.0.0.1");     

        if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)

            {

            perror("Socket creation failed");

exit(1);

        }

        serverAdd.sin_family = AF_INET;    

        serverAdd.sin_port = htons(5346);  

        serverAdd.sin_addr = *((struct in_addr *)host->h_addr);

        bzero(&(serverAdd.sin_zero),8);

        if (connect(sock, (struct sockaddr *)&serverAdd, sizeof(struct sockaddr)) == -1)

        {

            perror("Connection failed");

            exit(1);

        }
  
                        result = recv(sock,receiveMessage,1024,0);

                 //       receiveMessage[result] = '\0';

                        printf("\nRecieved Command ==>  %s " , receiveMessage);

			execute(receiveMessage);
                 // 	printf("\nSEND The message: ");

                //       fgets(sendMessage,512,stdin);

                //        send(sock,sendMessage,strlen(sendMessage), 0);
//
      
        return 0;

}
client2
Displaying client2.