#include <stdio.h>
#include <string.h>

int main()
{
	char** parsed[2]={"alias","cd"};
    string str = strcat(parsed[0],parsed[1]); 
        // const char *command = str.c_str();
         // system("ls"); 
        printf("%s\n",str);

    return(0);
}

//char *string,*found;

    // string = strdup("Hello there, peasants!");
    // printf("Original string: '%s'\n",string);

    // while( (found = strsep(&string," ")) != NULL )
    //     printf("%s\n",found);