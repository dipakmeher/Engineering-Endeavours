#include <sys/socket.h>

#include <sys/types.h>

#include <netinet/in.h>

#include <netdb.h>

#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <unistd.h>

#include <errno.h>

 
int sock;
int main()
{

        char sendMessage[512],receiveMessage[512];
    char fname[100] ,ch, file2[65536],cmd[10000];
    char ext[100] = "exit";
    FILE *fp;
    int i=0;
        int result; 

        struct hostent *host;

        struct sockaddr_in serverAdd; 

        host = gethostbyname("127.0.0.1");     

        if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)

            {

            perror("Socket creation failed");

exit(1);

        }

        serverAdd.sin_family = AF_INET;    

        serverAdd.sin_port = htons(6219);  

        serverAdd.sin_addr = *((struct in_addr *)host->h_addr);

        bzero(&(serverAdd.sin_zero),8);

        if (connect(sock, (struct sockaddr *)&serverAdd, sizeof(struct sockaddr)) == -1)

        {

            perror("Connection failed");

            exit(1);

        }

    while(1){
  
                        result = recv(sock,receiveMessage,1024,0);

                       receiveMessage[result] = '\0';

                        printf("\nRecieved Command ==>  %s " , receiveMessage);
            strcpy(cmd,receiveMessage);
            if(strcmp(ext,cmd ) == 0){
                exit(0);
            }
            printf("Executing Command: %s",cmd);
            system(cmd);
            strcpy(fname,"save.txt");
            fp = fopen(fname,"r");  
             while((ch = fgetc(fp)) != EOF){
                    file2[i]= ch;
                i++;
             }
            send(sock,file2,strlen(file2), 0);
            printf("\n Waiting for command....");
        
      }
        return 0;

}