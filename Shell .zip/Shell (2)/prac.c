// C program to illustrate 
// \a escape sequence 
#include <stdio.h> 
#include <readline/readline.h>
#include <readline/history.h>
int main(void) 
{ 
	int i,count;
  	char* buf;
  	char* str;
  	char *found;
  	char *strpiped[2];
  	buf = readline("\n>>> ");//take input
  	str =  strdup(buf);
  	printf("%d\n", strlen(buf));
    for (i = 0; i < strlen(buf); i++) { 
        strpiped[i] = strsep(&str, "|"); 

        if (strpiped[i]==NULL)
        {
        	break;
        }
        printf("%s\n", strpiped[i]);
    }

    return (0); 
} 

/*
// C program to illustrate \r escape  
// sequence 
#include <stdio.h> 
int main(void) 
{ 
    // Here we are using \r, which 
    // is carriage return character. 
    printf("Hello fri \r what ends"); 
    return (0); 
} 
*/