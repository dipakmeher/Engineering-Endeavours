// C Program to design a shell in Linux 
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <errno.h>
#include<readline/readline.h> 
#include<readline/history.h> 
  
#define MAXCOM 1000 // max number of letters to be supported 
#define MAXLIST 100 // max number of commands to be supported 
  
// Clearing the shell using escape sequences 
#define clear() printf("\033[H\033[J") 
  int result;
// Function to take input 
int takeInput(char* str) 
{ 
    char* buf;   
    buf = readline("\n>>> "); 

    if (strlen(buf) != 0) { 
        add_history(buf); 
        strcpy(str, buf); 

        //......................

        if(strcmp("join",buf)==0)
    {
          char sendMessage[1024] ,receiveMessage[1024];
          int sock, connected, result;        
          struct sockaddr_in serverAdd, clientAdd;   
          int length;
          if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
          {
                perror("Socket creation is failed");
               exit(1);
          }
          serverAdd.sin_family = AF_INET;        
          serverAdd.sin_port = htons(6787);
    serverAdd.sin_addr.s_addr = INADDR_ANY;
          bzero(&(serverAdd.sin_zero),8);
          if (bind(sock, (struct sockaddr *)&serverAdd, sizeof(struct sockaddr))== -1)
          {
                perror("Unable to bind");
                exit(1);
          }
          if (listen(sock, 3) == -1)
          {
                perror("Listen");
                exit(1);
          }
          printf("Waiting for client connection.......\n");
          fflush(stdout);
          while(1)
          { 
                length = sizeof(struct sockaddr_in);
                connected = accept(sock,(struct sockaddr *)&clientAdd,&length);
                printf("Server is connected with IP address %s and port %d\n",inet_ntoa(clientAdd.sin_addr),ntohs(clientAdd.sin_port));
                      
      while(1){
      printf("Send Command ==> ");
                        fgets(sendMessage,100,stdin);
                        send(connected, sendMessage,strlen(sendMessage), 0);      
      result = recv(connected,receiveMessage,512,0);
      receiveMessage[result] = '\0';
      printf("Received Output : %s \n" , receiveMessage);
                        fflush(stdout);
      }
      //exit(0);
          }
    
     }


        //......................
        return 0; 
    } else { 
        return 1; 
    } 
} 

//Colors
void green(){
  printf("\033[0;32m");
}
void red(){
  printf("\033[1;31m");
}
void defaultcolor(){
  printf("\033[0m;");
}

// Returns hostname for the local computer 
void checkHostName(int hostname) 
{ 
    if (hostname == -1) 
    { 
        perror("gethostname"); 
        exit(1); 
    } 
} 

// Function to print Current Directory. 
void currentDir() 
{ 
     char* username= getenv("USER");
    char cwd[1024]; 
    char* hostbuffer[256];
     int hostname;

     // To retrieve hostname 
    hostname = gethostname(hostbuffer, sizeof(hostbuffer)); 
    checkHostName(hostname);

    getcwd(cwd, sizeof(cwd)); 
    green();
    printf("\n%s@%s:",username,hostbuffer);
    red();
    printf("%s",cwd);
    defaultcolor(); 
   
} 
  
// Function where the system command is executed 
void checkArgs(char** parsed) 
{ 
    // Forking a child 
    pid_t pid = fork();  
  
    if (pid == -1) { 
        printf("\nFailed forking child.."); 
        return; 
    } else if (pid == 0) { 
        if (execvp(parsed[0], parsed) < 0) { 
            printf("\nCould not execute command.."); 
        } 
        exit(0); 
    } else { 
        // waiting for child to terminate 
        wait(NULL);  
        return; 
    } 
} 
  
// Function where the piped system commands is executed 
void checkArgsPiped(char** parsed, char** parsedpipe) 
{ 
    // 0 is read end, 1 is write end 
    int pipefd[2];  
    pid_t p1, p2; 
  
    if (pipe(pipefd) < 0) { 
        printf("\nPipe could not be initialized"); 
        return; 
    } 
    p1 = fork(); 
    if (p1 < 0) { 
        printf("\nCould not fork"); 
        return; 
    } 
  
    if (p1 == 0) { 
        close(pipefd[0]);   // Child 1 executing.. It only needs to write at the write end  
        dup2(pipefd[1], STDOUT_FILENO); 
        close(pipefd[1]); 
  
        if (execvp(parsed[0], parsed) < 0) { 
            printf("\nCould not execute command 1.."); 
            exit(0); 
        } 
    } else { 
        // Parent executing 
        p2 = fork(); 
  
        if (p2 < 0) { 
            printf("\nCould not fork"); 
            return; 
        } 
  
        // Child 2 executing.. It only needs to read at the read end 
        if (p2 == 0) { 
            close(pipefd[1]); 
            dup2(pipefd[0], STDIN_FILENO); 
            close(pipefd[0]); 
            if (execvp(parsedpipe[0], parsedpipe) < 0) { 
                printf("\nCould not execute command 2.."); 
                exit(0); 
            } 
        } else { 
            // parent executing, waiting for two children 
            wait(NULL); 
            wait(NULL); 
        } 
    } 
} 
  
// Help command builtin 
void openHelp() 
{ 
    puts("\n***WELCOME TO MY SHELL HELP***"
        "\nCopyright @ Suprotik Dey"
        "\n-Use the shell at your own risk..."
        "\nList of Commands supported:"
        "\n>cd"
        "\n>ls"
        "\n>exit"
        "\n>all other general commands available in UNIX shell"
        "\n>pipe handling"
        "\n>improper space handling"); 
  
    return; 
} 
  
void get_history(){

     /* get the state of your history list (offset, length, size) */
    HISTORY_STATE *myhist = history_get_history_state ();

    /* retrieve the history list */
    HIST_ENTRY **mylist = history_list ();

    printf ("Your history: \n");
    for (int i = 0; i < myhist->length; i++) { /* output history list */
        printf (" %s  %s\n", mylist[i]->line, mylist[i]->timestamp);
        free_history_entry (mylist[i]);     /* free allocated entries */
    }
    putchar ('\n');

    free (myhist);  /* free HIST_ENTRY list */
    free (mylist);  /* free HISTORY_STATE   */
    return;
}

// void get_connected(){
//     //................
//           char sendMessage[1024] ,receiveMessage[1024];
//           int sock, connected, result;        
//           struct sockaddr_in serverAdd, clientAdd;   
//           int length;
//           if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
//           {
//                 perror("Socket creation is failed");
//                exit(1);
//           }
//           serverAdd.sin_family = AF_INET;        
//           serverAdd.sin_port = htons(5654);
//             serverAdd.sin_add.rs_addr = INADDR_ANY;
//           bzero(&(serverAdd.sin_zero),8);
//           if (bind(sock, (struct sockaddr *)&serverAdd, sizeof(struct sockaddr))== -1)
//           {
//                 perror("Unable to bind");
//                 exit(1);
//           }
//           if (listen(sock, 3) == -1)
//           {
//                 perror("Listen");
//                 exit(1);
//           }
//           printf("Waiting for client connection.......\n");
//           fflush(stdout);
//           while(1)
//           { 
//                 length = sizeof(struct sockaddr_in);
//                 connected = accept(sock,(struct sockaddr *)&clientAdd,&length);
//                 printf("Server is connected with IP address %s and port %d\n",inet_ntoa(clientAdd.sin_addr),ntohs(clientAdd.sin_port));
                      
//       while(1){
//       printf("Send Command ==> ");
//                         fgets(sendMessage,100,stdin);
//                         send(connected, sendMessage,strlen(sendMessage), 0);      
//       result = recv(connected,receiveMessage,512,0);
//       receiveMessage[result] = '\0';
//       printf("Received Output : %s \n" , receiveMessage);
//                         fflush(stdout);
//       }
//       //exit(0);
//           }
    
//     return;
// }

// Function to execute builtin commands 
int ownCmdHandler(char** parsed) 
{ 
    int NoOfOwnCmds = 5, i, switchOwnArg = 0; 
    char* ListOfOwnCmds[NoOfOwnCmds]; 
    char* username; 
  
    ListOfOwnCmds[0] = "exit"; 
    ListOfOwnCmds[1] = "cd"; 
    ListOfOwnCmds[2] = "help"; 
    ListOfOwnCmds[3] = "hello";
    ListOfOwnCmds[4] = "history";
    // ListOfOwnCmds[5] = "join"; 
  
    for (i = 0; i < NoOfOwnCmds; i++) { 
        if (strcmp(parsed[0], ListOfOwnCmds[i]) == 0) { 
            switchOwnArg = i + 1; 
            break; 
        } 
    } 
  
    switch (switchOwnArg) { 
    case 1: 
        printf("\nGoodbye\n"); 
        exit(0); 
    case 2: 
        chdir(parsed[1]); 
        return 1; 
    case 3: 
        openHelp(); 
        return 1; 
    case 4: 
        username = getenv("USER"); 
        printf("\nHello %s. Thankyou for visiting here!!!", 
            username); 
        return 1;
    case 5: 
        get_history(); 
        return 1;
    // case 6: 
    //     get_connected();
    //     return 1; 
    default: 
        break; 
    } 
  
    return 0; 
} 
  
// function for finding pipe 
int parsePipe(char* str, char** strpiped) 
{ 
    int i; 
    for (i = 0; i < 2; i++) { 
        strpiped[i] = strsep(&str, "|"); 
        if (strpiped[i] == NULL) 
            break; 
    } 
  
    if (strpiped[1] == NULL) 
        return 0; // returns zero if no pipe is found. 
    else { 
        return 1; 
    } 
} 
  
// function for parsing command words 
void parseSpace(char* str, char** parsed) 
{ 
    int i; 
  
    for (i = 0; i < MAXLIST; i++) { 
        parsed[i] = strsep(&str, " "); 
  
        if (parsed[i] == NULL) 
            break; 
        if (strlen(parsed[i]) == 0) 
            i--; 
    } 
} 

//processsing input string
int processString(char* str, char** parsed, char** parsedpipe) 
{ 
  
    char* strpiped[2]; 
    int piped = 0; 
  
    piped = parsePipe(str, strpiped); 
    if (piped) { 
        parseSpace(strpiped[0], parsed); 
        parseSpace(strpiped[1], parsedpipe); 
  
    } else { 
  
        parseSpace(str, parsed); 
    } 
  
    if (ownCmdHandler(parsed)) 
        return 0; 
    else
        return 1 + piped; 
} 
  
int main() 
{ 
    char myInput[MAXCOM], *parsedInput[MAXLIST]; 
    char* parsedInputPiped[MAXLIST]; 
    int checkFlag = 0;  
  
    while (1) { 
        // print first line
        currentDir(); 
        // take input 
        if (takeInput(myInput)) 
            continue; 
        // process 
        checkFlag = processString(myInput, 
        parsedInput, parsedInputPiped);
  
        // execute 
        if (checkFlag == 1) 
            checkArgs(parsedInput); 
  
        if (checkFlag == 2) 
            checkArgsPiped(parsedInput, parsedInputPiped); 
    } 
    return 0; 
    }
    //gcc trial.c -L/usr/include -lreadline -o trial
