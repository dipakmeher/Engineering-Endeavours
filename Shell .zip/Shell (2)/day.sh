echo "abdc"

